<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Altura extends Model
{
    //
}
