<!--footer-->
<footer class="footer">
	<div class="container">
		<div class="row align-items-center flex-row-reverse">
			<div class="col-lg-12 col-sm-12 mt-3 mt-lg-0 text-center">
				Copyright © 2016 - {{date('Y')}} <a href="javascript:;">{{$appSetting->app_name}}</a>. All rights reserved.
			</div>
		</div>
	</div>
</footer>
<!-- End Footer-->