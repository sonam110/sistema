{!! Html::script('assets/js/vendors/jquery-3.2.1.min.js') !!}
{!! Html::script('assets/js/vendors/bootstrap.bundle.min.js') !!}
{!! Html::script('assets/js/vendors/jquery.sparkline.min.js') !!}
{!! Html::script('assets/js/vendors/selectize.min.js') !!}
{!! Html::script('assets/js/vendors/jquery.tablesorter.min.js') !!}
{!! Html::script('assets/js/vendors/circle-progress.min.js') !!}
{!! Html::script('assets/plugins/rating/jquery.rating-stars.js') !!}
{!! Html::script('assets/plugins/toggle-sidebar/sidemenu.js') !!}
{!! Html::script('assets/js/popover.js') !!}
{!! Html::script('assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js') !!}
{!! Html::script('assets/plugins/datatable/jquery.dataTables.min.js') !!}
{!! Html::script('assets/plugins/datatable/dataTables.bootstrap4.min.js') !!}
{!! Html::script('assets/plugins/datatable/datatable.js') !!}
{!! Html::script('assets/plugins/toastr/toastr.min.js') !!}
{!! Html::script('assets/plugins/select2/select2.full.min.js') !!}

{!! Html::script('assets/js/custom.js') !!}
{!! Html::script('assets/js/functions.js') !!}